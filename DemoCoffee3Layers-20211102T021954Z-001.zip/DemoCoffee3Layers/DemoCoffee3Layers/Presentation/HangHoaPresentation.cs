﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DemoCoffee3Layers.BUS;

namespace DemoCoffee3Layers.Presentation
{
    class HangHoaPresentation
    {
        private HangHoaBUS hhBUS = new HangHoaBUS();
        private DanhMucPresentation danhMucPre = new DanhMucPresentation();

        public void HienMenu()
        {
            bool end = false;
            while (!end)
            {
                Console.Clear(); //xóa màn hình

                Console.WriteLine("Quan ly hang hoa");
                Console.WriteLine("1. Hien danh sach hang hoa");
                Console.WriteLine("2. Them hang hoa");
                Console.WriteLine("3. Sua hang hoa");
                Console.WriteLine("4. Xoa hang hoa");
                Console.WriteLine("5. Quay lai");
                Console.Write("Chon: ");
                string s = Console.ReadLine();
                switch (s)
                {
                    case "1": HienHangHoa(); Console.ReadKey(); break;
                    case "2": ThemHangHoa(); Console.ReadKey(); break;
                    case "3": SuaHangHoa(); Console.ReadKey(); break;
                    case "4": XoaHangHoa(); Console.ReadKey(); break;
                    case "5": end = true; break;
                }
            }
        }

        public void HienHangHoa()
        {
            Console.WriteLine("Danh sach cac hang hoa:");
            foreach (String s in hhBUS.LayDanhSach())
            {
                Console.WriteLine(s);
            }

        }

        public void ThemHangHoa()
        {
            Console.WriteLine("Nhap thong tin cho hang hoa:");
            Console.Write("Nhap ma hang hoa: ");
            string ma = Console.ReadLine();
            Console.Write("Nhap ten hang hoa: ");
            string ten = Console.ReadLine();
            Console.Write("Nhap gia ban: ");
            int gia = int.Parse(Console.ReadLine());

            danhMucPre.HienDanhMuc();
            Console.Write("Chon danh muc: ");
            String danhMuc = Console.ReadLine();

            hhBUS.Them(ma, ten, gia, danhMuc);

            Console.WriteLine("Da them hang hoa!");
        }

        public void SuaHangHoa()
        {
            Console.Write("Nhap ma hang hoa can sua: ");
            string ma = Console.ReadLine();
            Console.Write("Nhap ten hang hoa moi: ");
            string ten = Console.ReadLine();
            Console.Write("Nhap gia ban: ");
            int gia = int.Parse(Console.ReadLine());

            danhMucPre.HienDanhMuc();
            Console.Write("Chon danh muc: ");
            String danhMuc = Console.ReadLine();

            hhBUS.Sua(ma, ten, gia, danhMuc);

            Console.WriteLine("Da sua hang hoa!");
        }

        public void XoaHangHoa()
        {
            Console.Write("Nhap ma hangHoa can xoa: ");
            string ma = Console.ReadLine();

            hhBUS.Xoa(ma);
            Console.WriteLine("Da xoa hang hoa!");
        }
    }
}
